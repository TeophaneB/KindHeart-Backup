<?php 

require('../../../../../config.php');
require_login();
?>
<!DOCTYPE html>
<html>
    <head>
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
		<link rel="stylesheet" type="text/css"  href="react/build/index.css">
		<link rel="shortcut icon" type="image/jpg" href="react/build/assets/images/recit.png"/>
    </head>
    <body>
        <div id="root"></div>
        <script type="text/javascript" src="react/build/index.js"></script>
    </body>
</html>